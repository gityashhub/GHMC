-- AlterTable
ALTER TABLE "users" ALTER COLUMN "role" SET DEFAULT 'admin';

-- CreateTable
CREATE TABLE "outward_materials" (
    "id" TEXT NOT NULL,
    "outward_entry_id" TEXT,
    "sr_no" INTEGER,
    "date" DATE,
    "cement_company" TEXT,
    "manifest_no" TEXT,
    "vehicle_no" TEXT,
    "waste_name" TEXT,
    "quantity" DECIMAL(10,2),
    "unit" TEXT,
    "transporter_name" TEXT,
    "invoice_no" TEXT,
    "vehicle_capacity" TEXT,
    "rate" DECIMAL(10,2),
    "amount" DECIMAL(10,2),
    "det_charges" DECIMAL(10,2),
    "gst" DECIMAL(10,2),
    "gross_amount" DECIMAL(10,2),
    "paid_on" DATE,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "outward_materials_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "outward_materials" ADD CONSTRAINT "outward_materials_outward_entry_id_fkey" FOREIGN KEY ("outward_entry_id") REFERENCES "outward_entries"("id") ON DELETE CASCADE ON UPDATE CASCADE;
