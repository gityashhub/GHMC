-- AlterTable
ALTER TABLE "inward_materials" ADD COLUMN     "month" TEXT;

-- AlterTable
ALTER TABLE "outward_materials" ADD COLUMN     "month" TEXT;
