-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password_hash" TEXT NOT NULL,
    "full_name" TEXT,
    "phone" TEXT,
    "role" TEXT NOT NULL DEFAULT 'user',
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "companies" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "address" TEXT,
    "city" TEXT,
    "contact" TEXT,
    "email" TEXT,
    "gst_number" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "companies_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "company_materials" (
    "id" TEXT NOT NULL,
    "company_id" TEXT NOT NULL,
    "material_name" TEXT NOT NULL,
    "rate" DECIMAL(10,2) NOT NULL,
    "unit" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "company_materials_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "transporters" (
    "id" TEXT NOT NULL,
    "transporter_id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "contact" TEXT,
    "address" TEXT,
    "email" TEXT,
    "gst_number" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "transporters_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inward_entries" (
    "id" TEXT NOT NULL,
    "sr_no" INTEGER,
    "date" DATE NOT NULL,
    "lot_no" TEXT,
    "company_id" TEXT NOT NULL,
    "manifest_no" TEXT NOT NULL,
    "vehicle_no" TEXT,
    "waste_name" TEXT NOT NULL,
    "rate" DECIMAL(10,2),
    "category" TEXT,
    "quantity" DECIMAL(10,2) NOT NULL,
    "unit" TEXT NOT NULL,
    "month" TEXT,
    "invoice_id" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inward_entries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inward_materials" (
    "id" TEXT NOT NULL,
    "inward_entry_id" TEXT,
    "sr_no" INTEGER,
    "date" DATE,
    "lot_no" TEXT,
    "company_id" TEXT,
    "manifest_no" TEXT,
    "vehicle_no" TEXT,
    "waste_name" TEXT,
    "category" TEXT,
    "quantity" DECIMAL(10,2),
    "unit" TEXT,
    "transporter_name" TEXT,
    "invoice_no" TEXT,
    "vehicle_capacity" TEXT,
    "rate" DECIMAL(10,2),
    "amount" DECIMAL(10,2),
    "det_charges" DECIMAL(10,2),
    "gst" DECIMAL(10,2),
    "gross_amount" DECIMAL(10,2),
    "paid_on" DATE,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inward_materials_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "outward_entries" (
    "id" TEXT NOT NULL,
    "sr_no" INTEGER,
    "month" TEXT,
    "date" DATE NOT NULL,
    "cement_company" TEXT NOT NULL,
    "location" TEXT,
    "manifest_no" TEXT NOT NULL,
    "transporter_id" TEXT,
    "vehicle_no" TEXT,
    "wasteName" TEXT,
    "quantity" DECIMAL(10,2) NOT NULL,
    "unit" TEXT NOT NULL,
    "packing" TEXT,
    "invoice_id" TEXT,
    "rate" DECIMAL(10,2),
    "amount" DECIMAL(10,2),
    "gst" DECIMAL(10,2),
    "gross_amount" DECIMAL(10,2),
    "vehicle_capacity" TEXT,
    "det_charges" DECIMAL(10,2),
    "paid_on" DATE,
    "due_on" DATE,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "outward_entries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "invoices" (
    "id" TEXT NOT NULL,
    "invoice_no" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "date" DATE NOT NULL,
    "customer_name" TEXT,
    "company_id" TEXT,
    "transporter_id" TEXT,
    "subtotal" DECIMAL(10,2) NOT NULL,
    "cgst" DECIMAL(10,2),
    "sgst" DECIMAL(10,2),
    "grand_total" DECIMAL(10,2) NOT NULL,
    "payment_received" DECIMAL(10,2) NOT NULL DEFAULT 0,
    "payment_received_on" DATE,
    "status" TEXT NOT NULL,
    "gst_no" TEXT,
    "billed_to" TEXT,
    "shipped_to" TEXT,
    "description" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "invoices_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "invoice_manifests" (
    "id" TEXT NOT NULL,
    "invoice_id" TEXT NOT NULL,
    "manifest_no" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "invoice_manifests_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "invoice_materials" (
    "id" TEXT NOT NULL,
    "invoice_id" TEXT NOT NULL,
    "material_name" TEXT NOT NULL,
    "rate" DECIMAL(10,2),
    "unit" TEXT,
    "quantity" DECIMAL(10,2),
    "amount" DECIMAL(10,2),
    "manifest_no" TEXT,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "invoice_materials_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "settings" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "value" TEXT,
    "type" TEXT NOT NULL DEFAULT 'string',
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "settings_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "companies_gst_number_key" ON "companies"("gst_number");

-- CreateIndex
CREATE UNIQUE INDEX "transporters_transporter_id_key" ON "transporters"("transporter_id");

-- CreateIndex
CREATE UNIQUE INDEX "inward_entries_lot_no_key" ON "inward_entries"("lot_no");

-- CreateIndex
CREATE INDEX "inward_entries_company_id_idx" ON "inward_entries"("company_id");

-- CreateIndex
CREATE INDEX "inward_entries_date_idx" ON "inward_entries"("date");

-- CreateIndex
CREATE INDEX "inward_entries_manifest_no_idx" ON "inward_entries"("manifest_no");

-- CreateIndex
CREATE INDEX "inward_entries_invoice_id_idx" ON "inward_entries"("invoice_id");

-- CreateIndex
CREATE INDEX "outward_entries_transporter_id_idx" ON "outward_entries"("transporter_id");

-- CreateIndex
CREATE INDEX "outward_entries_date_idx" ON "outward_entries"("date");

-- CreateIndex
CREATE INDEX "outward_entries_manifest_no_idx" ON "outward_entries"("manifest_no");

-- CreateIndex
CREATE INDEX "outward_entries_invoice_id_idx" ON "outward_entries"("invoice_id");

-- CreateIndex
CREATE UNIQUE INDEX "invoices_invoice_no_key" ON "invoices"("invoice_no");

-- CreateIndex
CREATE INDEX "invoices_type_idx" ON "invoices"("type");

-- CreateIndex
CREATE INDEX "invoices_status_idx" ON "invoices"("status");

-- CreateIndex
CREATE INDEX "invoices_date_idx" ON "invoices"("date");

-- CreateIndex
CREATE INDEX "invoices_company_id_idx" ON "invoices"("company_id");

-- CreateIndex
CREATE INDEX "invoices_transporter_id_idx" ON "invoices"("transporter_id");

-- CreateIndex
CREATE UNIQUE INDEX "settings_key_key" ON "settings"("key");

-- AddForeignKey
ALTER TABLE "company_materials" ADD CONSTRAINT "company_materials_company_id_fkey" FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inward_entries" ADD CONSTRAINT "inward_entries_company_id_fkey" FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inward_entries" ADD CONSTRAINT "inward_entries_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "invoices"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inward_materials" ADD CONSTRAINT "inward_materials_inward_entry_id_fkey" FOREIGN KEY ("inward_entry_id") REFERENCES "inward_entries"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "outward_entries" ADD CONSTRAINT "outward_entries_transporter_id_fkey" FOREIGN KEY ("transporter_id") REFERENCES "transporters"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "outward_entries" ADD CONSTRAINT "outward_entries_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "invoices"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_company_id_fkey" FOREIGN KEY ("company_id") REFERENCES "companies"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "invoices" ADD CONSTRAINT "invoices_transporter_id_fkey" FOREIGN KEY ("transporter_id") REFERENCES "transporters"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "invoice_manifests" ADD CONSTRAINT "invoice_manifests_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "invoices"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "invoice_materials" ADD CONSTRAINT "invoice_materials_invoice_id_fkey" FOREIGN KEY ("invoice_id") REFERENCES "invoices"("id") ON DELETE CASCADE ON UPDATE CASCADE;
